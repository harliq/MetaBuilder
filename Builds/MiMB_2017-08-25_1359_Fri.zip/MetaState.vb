﻿Public Class MetaState

End Class