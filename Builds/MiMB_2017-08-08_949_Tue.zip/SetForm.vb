﻿Module SetForm
    ' This module is to set form design depending on the selected Conditon or Action Type
    'Called from Click/change events to DGV or rule selection, Conditiong or Action ComboBox Changes/Selected Indexes
    Public SaveWork As Boolean = False

    'Condition Types
    Sub ResetCondition()
        frmMain.txtBoxCData.Enabled = True
        frmMain.txtBoxCData2.Enabled = True
        frmMain.txtBoxCData.Visible = False
        frmMain.txtBoxCData2.Visible = False
        frmMain.lblCData2.Visible = False
        frmMain.ListBoxCTDataAnyAll.Visible = False
        frmMain.btnAddAnyAll.Visible = False
        frmMain.cBoxCTAnyAll.Visible = False
        frmMain.btnDeleteAnyAll.Visible = False
        frmMain.btnEditAnyAll.Visible = False


    End Sub

    Sub ResetAll()


        ResetAction()
        ResetCondition()
        'frmMain.txtBoxCData.Enabled = True
        'frmMain.txtBoxCData2.Enabled = True
        'frmMain.txtBoxCData.Visible = False
        'frmMain.txtBoxCData2.Visible = False
        'frmMain.lblCData2.Visible = False

        'frmMain.txtBoxAData.Enabled = True
        'frmMain.txtBoxAData2.Enabled = True
        'frmMain.txtBoxAData3.Enabled = True

        'frmMain.txtBoxAData.Visible = False
        'frmMain.txtBoxAData2.Visible = False
        'frmMain.txtBoxAData3.Visible = False

        'frmMain.lblAdata2.Visible = False
        'frmMain.lblAData3.Visible = False

    End Sub
    Sub BlankRow()
        frmMain.txtBoxCData.Enabled = True
        frmMain.txtBoxCData.Visible = False
        frmMain.txtBoxCData2.Visible = False
        frmMain.txtBoxAData.Visible = False

    End Sub
    Sub CTNever()
        frmMain.lblCData.Text = "Never"
        'frmMain.txtBoxCData.Enabled = False
        'frmMain.txtBoxCData.Visible = False

    End Sub
    Sub CTAlways()
        frmMain.lblCData.Text = "Always"
        ' frmMain.txtBoxCData.Enabled = False
        'frmMain.txtBoxCData.Visible = False

    End Sub
    Sub CTAll()
        frmMain.lblCData.Text = "All"
        'frmMain.txtBoxCData.Enabled = True
        'frmMain.txtBoxCData.Visible = False
        frmMain.ListBoxCTDataAnyAll.Visible = True
        frmMain.btnAddAnyAll.Visible = True
        'frmMain.cBoxCTAnyAll.Visible = True
        frmMain.btnEditAnyAll.Visible = True
        frmMain.btnDeleteAnyAll.Visible = True


        'add Listbox for All Conditons
    End Sub
    Sub CTAny()
        frmMain.lblCData.Text = "Any"
        'frmMain.txtBoxCData.Enabled = False
        'frmMain.txtBoxCData.Visible = False
        frmMain.ListBoxCTDataAnyAll.Visible = True
        frmMain.btnAddAnyAll.Visible = True

        'add Listbox for Any Conditons

    End Sub
    Sub CTChatMessage()
        frmMain.lblCData.Text = "Chat Message"
        'frmMain.txtBoxCData.Enabled = True
        frmMain.txtBoxCData.Visible = True

    End Sub
    Sub CTMainPackSlotsLE()
        frmMain.lblCData.Text = "Pack Slots <="
        'frmMain.txtBoxCData.Enabled = True
        frmMain.txtBoxCData.Visible = True

    End Sub
    Sub CTSecondsinStateGE()
        frmMain.lblCData.Text = "Seconds in State >="
        'frmMain.txtBoxCData.Enabled = True
        frmMain.txtBoxCData.Visible = True

    End Sub
    Sub CTNavRouteEmpty()
        frmMain.lblCData.Text = "Nav Route Empty"
        'frmMain.txtBoxCData.Enabled = False
        'frmMain.txtBoxCData.Visible = False
    End Sub
    Sub CTDied()
        frmMain.lblCData.Text = "On Death"
        'frmMain.txtBoxCData.Enabled = False
        'frmMain.txtBoxCData.Visible = False
    End Sub
    Sub CTVendorOpen()
        frmMain.lblCData.Text = "Vendor Open"
        'frmMain.txtBoxCData.Enabled = True
        'frmMain.txtBoxCData.Visible = True
    End Sub
    Sub CTVendorClosed()
        frmMain.lblCData.Text = "Vendor Closed"
        'frmMain.txtBoxCData.Enabled = True
        'frmMain.txtBoxCData.Visible = True

    End Sub
    Sub CTItemCountLE()
        frmMain.lblCData.Text = "Item Name"
        frmMain.lblCData2.Text = "Item Count"
        frmMain.lblCData2.Visible = True
        'frmMain.txtBoxCData.Enabled = True
        frmMain.txtBoxCData.Visible = True
        frmMain.txtBoxCData2.Visible = True
        '**DONE**Add More labels, and Another Text Entry Box (2 Values)
    End Sub
    Sub CTItemCountGE()
        frmMain.lblCData.Text = "Item Name"
        frmMain.lblCData2.Text = "Item Count"
        frmMain.lblCData2.Visible = True
        ' frmMain.txtBoxCData.Enabled = True
        frmMain.txtBoxCData.Visible = True
        frmMain.txtBoxCData2.Visible = True
        '**DONE** Add More labels, and Another Text Entry Box (2 Values)
    End Sub
    Sub CTMonsterCountWithinDistance()
        frmMain.lblCData.Text = "Monster Count Within Distance"
        frmMain.txtBoxCData.Enabled = True
        frmMain.txtBoxCData.Visible = True
    End Sub
    Sub CTMonsterWithPriorityWithinDistance()
        frmMain.lblCData.Text = "Monster Priority Within Distance"
        frmMain.txtBoxCData.Enabled = True
        frmMain.txtBoxCData.Visible = True
    End Sub
    Sub CTNeedToBuff()
        frmMain.lblCData.Text = "Need to Buff"
        'frmMain.txtBoxCData.Enabled = False
        'frmMain.txtBoxCData.Visible = False

    End Sub
    Sub CTNoMonsterWithinDistance()
        frmMain.lblCData.Text = "No Monster Within Distance"
        'frmMain.txtBoxCData.Enabled = True
        frmMain.txtBoxCData.Visible = True
    End Sub
    Sub CTLandBlockE()
        frmMain.lblCData.Text = "Landblock ="
        'frmMain.txtBoxCData.Enabled = True
        frmMain.txtBoxCData.Visible = True

    End Sub
    Sub CTLandColumnE()
        frmMain.lblCData.Text = "Landcell ="
        'frmMain.txtBoxCData.Enabled = True
        frmMain.txtBoxCData.Visible = True
    End Sub
    Sub CTPortalSpaceEnter()
        frmMain.lblCData.Text = "Enter Portal Space"
        'frmMain.txtBoxCData.Enabled = False
        'frmMain.txtBoxCData.Visible = False

    End Sub
    Sub CTPortalSpaceExit()
        frmMain.lblCData.Text = "Exit Portal Space"
        'frmMain.txtBoxCData.Enabled = False
        'frmMain.txtBoxCData.Visible = False

    End Sub
    Sub CTNot()
        frmMain.lblCData.Text = "Not"
        'frmMain.txtBoxCData.Enabled = True
        'frmMain.txtBoxCData.Visible = True

    End Sub
    Sub CTSecondsInStatePersistGE()
        frmMain.lblCData.Text = "Seconds in State Persist >="
        'frmMain.txtBoxCData.Enabled = True
        frmMain.txtBoxCData.Visible = True

    End Sub
    Sub CTTimeLeftOnSpellGE()
        frmMain.lblCData.Text = "Time left on spell >= (Seconds)"
        'frmMain.txtBoxCData.Enabled = True
        frmMain.txtBoxCData.Visible = True

    End Sub
    Sub CTBurdenPercentGE()
        frmMain.lblCData.Text = "Burden Percentage >="
        'frmMain.txtBoxCData.Enabled = True
        frmMain.txtBoxCData.Visible = True

    End Sub
    Sub CTDistanceToAnyRoutePointGE()
        frmMain.lblCData.Text = "Distance to Route Point >="
        'frmMain.txtBoxCData.Enabled = True
        frmMain.txtBoxCData.Visible = True

    End Sub
    Sub CTExpression()
        frmMain.lblCData.Text = "Chat Expression"
        'frmMain.txtBoxCData.Enabled = True
        frmMain.txtBoxCData.Visible = True

    End Sub
    Sub CTClientDialogPopup()
        frmMain.lblCData.Text = "Client Dialog PopUp - DISABLED, NOT IN GAME"
        'frmMain.txtBoxCData.Enabled = False
        'frmMain.txtBoxCData.Visible = False

    End Sub
    Sub CTChatMessageCapture()
        frmMain.lblCData.Text = "Chat Message Pattern"
        frmMain.lblCData2.Text = "Chat ColorID List"
        frmMain.lblCData2.Visible = True
        'frmMain.txtBoxCData.Enabled = True
        frmMain.txtBoxCData.Visible = True
        frmMain.txtBoxCData2.Visible = True


    End Sub

    'Action Types
    Sub ResetAction()
        frmMain.txtBoxAData.Enabled = True
        frmMain.txtBoxAData2.Enabled = True
        frmMain.txtBoxAData3.Enabled = True

        frmMain.txtBoxAData.Visible = False
        frmMain.txtBoxAData2.Visible = False
        frmMain.txtBoxAData3.Visible = False

        frmMain.lblAdata2.Visible = False
        frmMain.lblAData3.Visible = False

        frmMain.btnChooseNav.Visible = False

        'frmMain.ListBoxCTDataAnyAll.Visible = False
        'frmMain.btnAddCdata.Visible = False
    End Sub

    Sub ATSingleRule()
        frmMain.txtBoxAData.Visible = True
    End Sub
    Sub ATDoubleRule()
        frmMain.txtBoxAData.Visible = True
        frmMain.txtBoxAData2.Visible = True
    End Sub
    Sub ATTripleRule()
        frmMain.txtBoxAData.Visible = True
        frmMain.txtBoxAData2.Visible = True
        frmMain.txtBoxAData3.Visible = True
    End Sub

    Sub ATNone()
        frmMain.lblAData.Text = "None"
        frmMain.txtBoxAData.Text = "0"
        'frmMain.txtBoxAData.Enabled = False
    End Sub
    Sub ATSetState()
        'frmMain.txtBoxAData.Enabled = False
        frmMain.txtBoxAData.Visible = False
        frmMain.cBoxATMetaState.Visible = True
        frmMain.lblATMetaState.Visible = True
        frmMain.lblAData.Visible = False

    End Sub
    Sub ATChatCommand()
        'frmMain.txtBoxAData.Enabled = True
        frmMain.txtBoxAData.Visible = True
        frmMain.cBoxATMetaState.Visible = False
        frmMain.lblATMetaState.Visible = False
        frmMain.lblAData.Visible = True
        frmMain.lblAData.Text = "Chat Command"

    End Sub
    Sub ATMultiple()
        'frmMain.txtBoxAData.Enabled = True
        frmMain.txtBoxAData.Visible = True
        frmMain.cBoxATMetaState.Visible = False
        frmMain.lblATMetaState.Visible = False
        frmMain.lblAData.Visible = True
        frmMain.lblAData.Text = "Multiple"
    End Sub

    Sub ATEmbeddedNav()
        'frmMain.txtBoxAData.Enabled = True
        frmMain.txtBoxAData.Visible = True
        frmMain.cBoxATMetaState.Visible = False
        frmMain.lblATMetaState.Visible = False
        frmMain.lblAData.Visible = True
        frmMain.btnChooseNav.Visible = True
        frmMain.lblAData.Text = "Embedded Nav - Choose File"

    End Sub

    Sub ATCallState()
        'frmMain.txtBoxAData.Enabled = False
        frmMain.txtBoxAData.Visible = False
        frmMain.cBoxATMetaState.Visible = True
        frmMain.lblATMetaState.Visible = True
        frmMain.lblAData.Visible = False
    End Sub
    Sub ATReturnFromCall()
        'frmMain.txtBoxAData.Enabled = True
        'frmMain.txtBoxAData.Visible = True
        frmMain.cBoxATMetaState.Visible = False
        frmMain.lblATMetaState.Visible = False
        frmMain.lblAData.Visible = True
        frmMain.lblAData.Text = "Return From Call"
    End Sub
    Sub ATExpressionAction()
        'frmMain.txtBoxAData.Enabled = True
        frmMain.txtBoxAData.Visible = True
        frmMain.cBoxATMetaState.Visible = False
        frmMain.lblATMetaState.Visible = False
        frmMain.lblAData.Visible = True
        frmMain.lblAData.Text = "Expression Action"
    End Sub
    Sub ATChatWithExpression()
        'frmMain.txtBoxAData.Enabled = True
        frmMain.txtBoxAData.Visible = True
        frmMain.cBoxATMetaState.Visible = False
        frmMain.lblATMetaState.Visible = False
        frmMain.lblAData.Visible = True
        frmMain.lblAData.Text = "Chat Expression"

    End Sub
    Sub ATWatchDogSet()
        'frmMain.txtBoxAData.Enabled = True
        frmMain.txtBoxAData.Visible = True
        frmMain.txtBoxAData2.Visible = True
        frmMain.txtBoxAData3.Visible = True
        frmMain.cBoxATMetaState.Visible = False
        frmMain.lblATMetaState.Visible = False
        frmMain.lblAData.Visible = True
        frmMain.lblAdata2.Visible = True
        frmMain.lblAData3.Visible = True
        frmMain.lblAData.Text = "State to Call:"
        frmMain.lblAdata2.Text = "Movement Range (Meters):"
        frmMain.lblAData3.Text = "Time Span (Seconds):"

    End Sub
    Sub ATWatchDogClear()
        'frmMain.txtBoxAData.Enabled = True
        'frmMain.txtBoxAData.Visible = True
        'frmMain.cBoxATMetaState.Visible = False
        'frmMain.lblATMetaState.Visible = False
        frmMain.lblAData.Visible = True
        frmMain.lblAData.Text = "WatchDog Clear"

    End Sub
    Sub ATGetVTOption()
        'frmMain.txtBoxAData.Enabled = True
        frmMain.txtBoxAData.Visible = True
        frmMain.txtBoxAData2.Visible = True
        frmMain.cBoxATMetaState.Visible = False
        frmMain.lblATMetaState.Visible = False
        frmMain.lblAData.Visible = True
        frmMain.lblAdata2.Visible = True
        frmMain.lblAData.Text = "Option to Get"
        frmMain.lblAdata2.Text = "Expression Variable Target"

    End Sub
    Sub ATSetVTOption()
        'frmMain.txtBoxAData.Enabled = True
        frmMain.txtBoxAData.Visible = True
        frmMain.txtBoxAData2.Visible = True
        frmMain.cBoxATMetaState.Visible = False
        frmMain.lblATMetaState.Visible = False
        frmMain.lblAData.Visible = True
        frmMain.lblAdata2.Visible = True
        frmMain.lblAData.Text = "Option to Set"
        frmMain.lblAdata2.Text = "Expresssion"
    End Sub
End Module
