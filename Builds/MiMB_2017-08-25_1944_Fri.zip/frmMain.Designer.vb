﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolsToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.OptionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveAsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PasteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NavRoutesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OptionsToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.ToolStripButtonNew = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButtonOpen = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButtonSave = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripButtonExport = New System.Windows.Forms.ToolStripButton()
        Me.tsbNew = New System.Windows.Forms.ToolStripButton()
        Me.tsbOpen = New System.Windows.Forms.ToolStripButton()
        Me.tsbSave = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.tsbExportMeta = New System.Windows.Forms.ToolStripButton()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.btnAddAnyAll = New System.Windows.Forms.Button()
        Me.dgvAnyAll = New System.Windows.Forms.DataGridView()
        Me.btnUp = New System.Windows.Forms.Button()
        Me.btnInsertRule = New System.Windows.Forms.Button()
        Me.btnDeleteAnyAll = New System.Windows.Forms.Button()
        Me.btnEditAnyAll = New System.Windows.Forms.Button()
        Me.cBoxCTAnyAll = New System.Windows.Forms.ComboBox()
        Me.btnDeleteRule = New System.Windows.Forms.Button()
        Me.lblCData2 = New System.Windows.Forms.Label()
        Me.txtBoxCData2 = New System.Windows.Forms.TextBox()
        Me.txtBoxCData = New System.Windows.Forms.TextBox()
        Me.lblCData = New System.Windows.Forms.Label()
        Me.ListBoxCTDataAnyAll = New System.Windows.Forms.ListBox()
        Me.cBoxCType = New System.Windows.Forms.ComboBox()
        Me.cBoxCTMetaState = New System.Windows.Forms.ComboBox()
        Me.btnCreateState = New System.Windows.Forms.Button()
        Me.lblCTMetaState = New System.Windows.Forms.Label()
        Me.lblCType = New System.Windows.Forms.Label()
        Me.btnDeleteATAnyAll = New System.Windows.Forms.Button()
        Me.dgvATMultiple = New System.Windows.Forms.DataGridView()
        Me.btnEditATAnyAll = New System.Windows.Forms.Button()
        Me.btnDown = New System.Windows.Forms.Button()
        Me.btnAddATAnyAll = New System.Windows.Forms.Button()
        Me.btnTest = New System.Windows.Forms.Button()
        Me.btnChooseNav = New System.Windows.Forms.Button()
        Me.btnLoadXML = New System.Windows.Forms.Button()
        Me.btnSaveXML = New System.Windows.Forms.Button()
        Me.btnExportMeta = New System.Windows.Forms.Button()
        Me.buttonTest = New System.Windows.Forms.Button()
        Me.lblAData3 = New System.Windows.Forms.Label()
        Me.txtBoxAData3 = New System.Windows.Forms.TextBox()
        Me.lblAdata2 = New System.Windows.Forms.Label()
        Me.txtBoxAData2 = New System.Windows.Forms.TextBox()
        Me.cBoxAType = New System.Windows.Forms.ComboBox()
        Me.cBoxATMetaState = New System.Windows.Forms.ComboBox()
        Me.lblATMetaState = New System.Windows.Forms.Label()
        Me.txtBoxAData = New System.Windows.Forms.TextBox()
        Me.lblAData = New System.Windows.Forms.Label()
        Me.lblAType = New System.Windows.Forms.Label()
        Me.btnCreateRule = New System.Windows.Forms.Button()
        Me.dgvMetaRules = New System.Windows.Forms.DataGridView()
        Me.btnUpdateRule = New System.Windows.Forms.Button()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.SaveFileDialogMeta = New System.Windows.Forms.SaveFileDialog()
        Me.btnATCreateState = New System.Windows.Forms.Button()
        Me.MenuStrip1.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.dgvAnyAll, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvATMultiple, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvMetaRules, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem1, Me.ToolsToolStripMenuItem1, Me.HelpToolStripMenuItem1})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1234, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem1
        '
        Me.FileToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewToolStripMenuItem1, Me.OpenToolStripMenuItem1, Me.SaveToolStripMenuItem1, Me.ExitToolStripMenuItem1})
        Me.FileToolStripMenuItem1.Name = "FileToolStripMenuItem1"
        Me.FileToolStripMenuItem1.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem1.Text = "&File"
        '
        'NewToolStripMenuItem1
        '
        Me.NewToolStripMenuItem1.Name = "NewToolStripMenuItem1"
        Me.NewToolStripMenuItem1.Size = New System.Drawing.Size(103, 22)
        Me.NewToolStripMenuItem1.Text = "&New"
        '
        'OpenToolStripMenuItem1
        '
        Me.OpenToolStripMenuItem1.Name = "OpenToolStripMenuItem1"
        Me.OpenToolStripMenuItem1.Size = New System.Drawing.Size(103, 22)
        Me.OpenToolStripMenuItem1.Text = "&Open"
        '
        'SaveToolStripMenuItem1
        '
        Me.SaveToolStripMenuItem1.Name = "SaveToolStripMenuItem1"
        Me.SaveToolStripMenuItem1.Size = New System.Drawing.Size(103, 22)
        Me.SaveToolStripMenuItem1.Text = "&Save"
        '
        'ExitToolStripMenuItem1
        '
        Me.ExitToolStripMenuItem1.Name = "ExitToolStripMenuItem1"
        Me.ExitToolStripMenuItem1.Size = New System.Drawing.Size(103, 22)
        Me.ExitToolStripMenuItem1.Text = "E&xit"
        '
        'ToolsToolStripMenuItem1
        '
        Me.ToolsToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OptionsToolStripMenuItem})
        Me.ToolsToolStripMenuItem1.Name = "ToolsToolStripMenuItem1"
        Me.ToolsToolStripMenuItem1.Size = New System.Drawing.Size(47, 20)
        Me.ToolsToolStripMenuItem1.Text = "&Tools"
        '
        'OptionsToolStripMenuItem
        '
        Me.OptionsToolStripMenuItem.Name = "OptionsToolStripMenuItem"
        Me.OptionsToolStripMenuItem.Size = New System.Drawing.Size(116, 22)
        Me.OptionsToolStripMenuItem.Text = "&O&ptions"
        '
        'HelpToolStripMenuItem1
        '
        Me.HelpToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutToolStripMenuItem1})
        Me.HelpToolStripMenuItem1.Name = "HelpToolStripMenuItem1"
        Me.HelpToolStripMenuItem1.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem1.Text = "&Help"
        '
        'AboutToolStripMenuItem1
        '
        Me.AboutToolStripMenuItem1.Name = "AboutToolStripMenuItem1"
        Me.AboutToolStripMenuItem1.Size = New System.Drawing.Size(107, 22)
        Me.AboutToolStripMenuItem1.Text = "&About"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewToolStripMenuItem, Me.OpenToolStripMenuItem, Me.SaveToolStripMenuItem, Me.SaveAsToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'NewToolStripMenuItem
        '
        Me.NewToolStripMenuItem.Name = "NewToolStripMenuItem"
        Me.NewToolStripMenuItem.Size = New System.Drawing.Size(114, 22)
        Me.NewToolStripMenuItem.Text = "New"
        '
        'OpenToolStripMenuItem
        '
        Me.OpenToolStripMenuItem.Name = "OpenToolStripMenuItem"
        Me.OpenToolStripMenuItem.Size = New System.Drawing.Size(114, 22)
        Me.OpenToolStripMenuItem.Text = "Open"
        '
        'SaveToolStripMenuItem
        '
        Me.SaveToolStripMenuItem.Name = "SaveToolStripMenuItem"
        Me.SaveToolStripMenuItem.Size = New System.Drawing.Size(114, 22)
        Me.SaveToolStripMenuItem.Text = "Save"
        '
        'SaveAsToolStripMenuItem
        '
        Me.SaveAsToolStripMenuItem.Name = "SaveAsToolStripMenuItem"
        Me.SaveAsToolStripMenuItem.Size = New System.Drawing.Size(114, 22)
        Me.SaveAsToolStripMenuItem.Text = "Save As"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(114, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'EditToolStripMenuItem
        '
        Me.EditToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CopyToolStripMenuItem, Me.PasteToolStripMenuItem})
        Me.EditToolStripMenuItem.Name = "EditToolStripMenuItem"
        Me.EditToolStripMenuItem.Size = New System.Drawing.Size(39, 20)
        Me.EditToolStripMenuItem.Text = "Edit"
        '
        'CopyToolStripMenuItem
        '
        Me.CopyToolStripMenuItem.Name = "CopyToolStripMenuItem"
        Me.CopyToolStripMenuItem.Size = New System.Drawing.Size(102, 22)
        Me.CopyToolStripMenuItem.Text = "Copy"
        '
        'PasteToolStripMenuItem
        '
        Me.PasteToolStripMenuItem.Name = "PasteToolStripMenuItem"
        Me.PasteToolStripMenuItem.Size = New System.Drawing.Size(102, 22)
        Me.PasteToolStripMenuItem.Text = "Paste"
        '
        'ToolsToolStripMenuItem
        '
        Me.ToolsToolStripMenuItem.Name = "ToolsToolStripMenuItem"
        Me.ToolsToolStripMenuItem.Size = New System.Drawing.Size(47, 20)
        Me.ToolsToolStripMenuItem.Text = "Tools"
        '
        'NavRoutesToolStripMenuItem
        '
        Me.NavRoutesToolStripMenuItem.Name = "NavRoutesToolStripMenuItem"
        Me.NavRoutesToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.NavRoutesToolStripMenuItem.Text = "Nav Routes"
        '
        'OptionsToolStripMenuItem1
        '
        Me.OptionsToolStripMenuItem1.Name = "OptionsToolStripMenuItem1"
        Me.OptionsToolStripMenuItem1.Size = New System.Drawing.Size(152, 22)
        Me.OptionsToolStripMenuItem1.Text = "Options"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HelpFileToolStripMenuItem, Me.AboutToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'HelpFileToolStripMenuItem
        '
        Me.HelpFileToolStripMenuItem.Name = "HelpFileToolStripMenuItem"
        Me.HelpFileToolStripMenuItem.Size = New System.Drawing.Size(120, 22)
        Me.HelpFileToolStripMenuItem.Text = "Help File"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(120, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripButtonNew, Me.ToolStripButtonOpen, Me.ToolStripButtonSave, Me.ToolStripSeparator2, Me.ToolStripButtonExport})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 24)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(1234, 25)
        Me.ToolStrip1.TabIndex = 1
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ToolStripButtonNew
        '
        Me.ToolStripButtonNew.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButtonNew.Image = CType(resources.GetObject("ToolStripButtonNew.Image"), System.Drawing.Image)
        Me.ToolStripButtonNew.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButtonNew.Name = "ToolStripButtonNew"
        Me.ToolStripButtonNew.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButtonNew.Text = "New"
        '
        'ToolStripButtonOpen
        '
        Me.ToolStripButtonOpen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButtonOpen.Image = CType(resources.GetObject("ToolStripButtonOpen.Image"), System.Drawing.Image)
        Me.ToolStripButtonOpen.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButtonOpen.Name = "ToolStripButtonOpen"
        Me.ToolStripButtonOpen.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButtonOpen.Text = "Open"
        '
        'ToolStripButtonSave
        '
        Me.ToolStripButtonSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButtonSave.Image = CType(resources.GetObject("ToolStripButtonSave.Image"), System.Drawing.Image)
        Me.ToolStripButtonSave.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButtonSave.Name = "ToolStripButtonSave"
        Me.ToolStripButtonSave.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButtonSave.Text = "Save"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripButtonExport
        '
        Me.ToolStripButtonExport.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButtonExport.Image = CType(resources.GetObject("ToolStripButtonExport.Image"), System.Drawing.Image)
        Me.ToolStripButtonExport.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButtonExport.Name = "ToolStripButtonExport"
        Me.ToolStripButtonExport.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButtonExport.Text = "Export to Meta"
        '
        'tsbNew
        '
        Me.tsbNew.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbNew.Image = CType(resources.GetObject("tsbNew.Image"), System.Drawing.Image)
        Me.tsbNew.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbNew.Name = "tsbNew"
        Me.tsbNew.Size = New System.Drawing.Size(23, 22)
        Me.tsbNew.Text = "New"
        '
        'tsbOpen
        '
        Me.tsbOpen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbOpen.Image = CType(resources.GetObject("tsbOpen.Image"), System.Drawing.Image)
        Me.tsbOpen.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbOpen.Name = "tsbOpen"
        Me.tsbOpen.Size = New System.Drawing.Size(23, 22)
        Me.tsbOpen.Text = "Open"
        '
        'tsbSave
        '
        Me.tsbSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbSave.Image = CType(resources.GetObject("tsbSave.Image"), System.Drawing.Image)
        Me.tsbSave.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbSave.Name = "tsbSave"
        Me.tsbSave.Size = New System.Drawing.Size(23, 22)
        Me.tsbSave.Text = "Save"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'tsbExportMeta
        '
        Me.tsbExportMeta.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbExportMeta.Image = CType(resources.GetObject("tsbExportMeta.Image"), System.Drawing.Image)
        Me.tsbExportMeta.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbExportMeta.Name = "tsbExportMeta"
        Me.tsbExportMeta.Size = New System.Drawing.Size(23, 22)
        Me.tsbExportMeta.Text = "Export Meta"
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 367)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.BackColor = System.Drawing.SystemColors.ControlLight
        Me.SplitContainer1.Panel1.Controls.Add(Me.btnAddAnyAll)
        Me.SplitContainer1.Panel1.Controls.Add(Me.dgvAnyAll)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btnUp)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btnInsertRule)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btnDeleteAnyAll)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btnEditAnyAll)
        Me.SplitContainer1.Panel1.Controls.Add(Me.cBoxCTAnyAll)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btnDeleteRule)
        Me.SplitContainer1.Panel1.Controls.Add(Me.lblCData2)
        Me.SplitContainer1.Panel1.Controls.Add(Me.txtBoxCData2)
        Me.SplitContainer1.Panel1.Controls.Add(Me.txtBoxCData)
        Me.SplitContainer1.Panel1.Controls.Add(Me.lblCData)
        Me.SplitContainer1.Panel1.Controls.Add(Me.ListBoxCTDataAnyAll)
        Me.SplitContainer1.Panel1.Controls.Add(Me.cBoxCType)
        Me.SplitContainer1.Panel1.Controls.Add(Me.cBoxCTMetaState)
        Me.SplitContainer1.Panel1.Controls.Add(Me.btnCreateState)
        Me.SplitContainer1.Panel1.Controls.Add(Me.lblCTMetaState)
        Me.SplitContainer1.Panel1.Controls.Add(Me.lblCType)
        Me.SplitContainer1.Panel1.Margin = New System.Windows.Forms.Padding(1)
        Me.SplitContainer1.Panel1.Padding = New System.Windows.Forms.Padding(1)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.BackColor = System.Drawing.SystemColors.ControlLight
        Me.SplitContainer1.Panel2.Controls.Add(Me.btnATCreateState)
        Me.SplitContainer1.Panel2.Controls.Add(Me.btnDeleteATAnyAll)
        Me.SplitContainer1.Panel2.Controls.Add(Me.dgvATMultiple)
        Me.SplitContainer1.Panel2.Controls.Add(Me.btnEditATAnyAll)
        Me.SplitContainer1.Panel2.Controls.Add(Me.btnDown)
        Me.SplitContainer1.Panel2.Controls.Add(Me.btnAddATAnyAll)
        Me.SplitContainer1.Panel2.Controls.Add(Me.btnTest)
        Me.SplitContainer1.Panel2.Controls.Add(Me.btnChooseNav)
        Me.SplitContainer1.Panel2.Controls.Add(Me.btnLoadXML)
        Me.SplitContainer1.Panel2.Controls.Add(Me.btnSaveXML)
        Me.SplitContainer1.Panel2.Controls.Add(Me.btnExportMeta)
        Me.SplitContainer1.Panel2.Controls.Add(Me.buttonTest)
        Me.SplitContainer1.Panel2.Controls.Add(Me.lblAData3)
        Me.SplitContainer1.Panel2.Controls.Add(Me.txtBoxAData3)
        Me.SplitContainer1.Panel2.Controls.Add(Me.lblAdata2)
        Me.SplitContainer1.Panel2.Controls.Add(Me.txtBoxAData2)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cBoxAType)
        Me.SplitContainer1.Panel2.Controls.Add(Me.cBoxATMetaState)
        Me.SplitContainer1.Panel2.Controls.Add(Me.lblATMetaState)
        Me.SplitContainer1.Panel2.Controls.Add(Me.txtBoxAData)
        Me.SplitContainer1.Panel2.Controls.Add(Me.lblAData)
        Me.SplitContainer1.Panel2.Controls.Add(Me.lblAType)
        Me.SplitContainer1.Size = New System.Drawing.Size(1234, 494)
        Me.SplitContainer1.SplitterDistance = 243
        Me.SplitContainer1.TabIndex = 11
        '
        'btnAddAnyAll
        '
        Me.btnAddAnyAll.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddAnyAll.Location = New System.Drawing.Point(341, 79)
        Me.btnAddAnyAll.Name = "btnAddAnyAll"
        Me.btnAddAnyAll.Size = New System.Drawing.Size(92, 32)
        Me.btnAddAnyAll.TabIndex = 21
        Me.btnAddAnyAll.Text = "&Add"
        Me.btnAddAnyAll.UseVisualStyleBackColor = True
        Me.btnAddAnyAll.Visible = False
        '
        'dgvAnyAll
        '
        Me.dgvAnyAll.AllowUserToResizeRows = False
        Me.dgvAnyAll.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvAnyAll.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgvAnyAll.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvAnyAll.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.dgvAnyAll.Location = New System.Drawing.Point(14, 79)
        Me.dgvAnyAll.MultiSelect = False
        Me.dgvAnyAll.Name = "dgvAnyAll"
        Me.dgvAnyAll.RowHeadersVisible = False
        Me.dgvAnyAll.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.dgvAnyAll.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvAnyAll.ShowCellErrors = False
        Me.dgvAnyAll.ShowCellToolTips = False
        Me.dgvAnyAll.ShowEditingIcon = False
        Me.dgvAnyAll.Size = New System.Drawing.Size(302, 161)
        Me.dgvAnyAll.TabIndex = 28
        '
        'btnUp
        '
        Me.btnUp.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnUp.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUp.Location = New System.Drawing.Point(1101, 209)
        Me.btnUp.Name = "btnUp"
        Me.btnUp.Size = New System.Drawing.Size(129, 30)
        Me.btnUp.TabIndex = 28
        Me.btnUp.Text = "Row Up"
        Me.btnUp.UseVisualStyleBackColor = True
        '
        'btnInsertRule
        '
        Me.btnInsertRule.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnInsertRule.Enabled = False
        Me.btnInsertRule.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnInsertRule.Location = New System.Drawing.Point(1101, 139)
        Me.btnInsertRule.Name = "btnInsertRule"
        Me.btnInsertRule.Size = New System.Drawing.Size(129, 32)
        Me.btnInsertRule.TabIndex = 29
        Me.btnInsertRule.Text = "&Insert Rule"
        Me.btnInsertRule.UseVisualStyleBackColor = True
        Me.btnInsertRule.Visible = False
        '
        'btnDeleteAnyAll
        '
        Me.btnDeleteAnyAll.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDeleteAnyAll.Location = New System.Drawing.Point(340, 153)
        Me.btnDeleteAnyAll.Name = "btnDeleteAnyAll"
        Me.btnDeleteAnyAll.Size = New System.Drawing.Size(92, 32)
        Me.btnDeleteAnyAll.TabIndex = 27
        Me.btnDeleteAnyAll.Text = "De&lete"
        Me.btnDeleteAnyAll.UseVisualStyleBackColor = True
        Me.btnDeleteAnyAll.Visible = False
        '
        'btnEditAnyAll
        '
        Me.btnEditAnyAll.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEditAnyAll.Location = New System.Drawing.Point(341, 115)
        Me.btnEditAnyAll.Name = "btnEditAnyAll"
        Me.btnEditAnyAll.Size = New System.Drawing.Size(92, 32)
        Me.btnEditAnyAll.TabIndex = 26
        Me.btnEditAnyAll.Text = "&Edit"
        Me.btnEditAnyAll.UseVisualStyleBackColor = True
        Me.btnEditAnyAll.Visible = False
        '
        'cBoxCTAnyAll
        '
        Me.cBoxCTAnyAll.DropDownHeight = 150
        Me.cBoxCTAnyAll.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cBoxCTAnyAll.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cBoxCTAnyAll.FormattingEnabled = True
        Me.cBoxCTAnyAll.IntegralHeight = False
        Me.cBoxCTAnyAll.Location = New System.Drawing.Point(703, 23)
        Me.cBoxCTAnyAll.MaxDropDownItems = 30
        Me.cBoxCTAnyAll.Name = "cBoxCTAnyAll"
        Me.cBoxCTAnyAll.Size = New System.Drawing.Size(279, 28)
        Me.cBoxCTAnyAll.TabIndex = 25
        '
        'btnDeleteRule
        '
        Me.btnDeleteRule.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnDeleteRule.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDeleteRule.Location = New System.Drawing.Point(1101, 101)
        Me.btnDeleteRule.Name = "btnDeleteRule"
        Me.btnDeleteRule.Size = New System.Drawing.Size(129, 32)
        Me.btnDeleteRule.TabIndex = 23
        Me.btnDeleteRule.Text = "&Delete Rule"
        Me.btnDeleteRule.UseVisualStyleBackColor = True
        '
        'lblCData2
        '
        Me.lblCData2.AutoSize = True
        Me.lblCData2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCData2.Location = New System.Drawing.Point(12, 119)
        Me.lblCData2.Name = "lblCData2"
        Me.lblCData2.Size = New System.Drawing.Size(166, 20)
        Me.lblCData2.TabIndex = 24
        Me.lblCData2.Text = "Condition Type Data 2"
        '
        'txtBoxCData2
        '
        Me.txtBoxCData2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBoxCData2.Location = New System.Drawing.Point(16, 142)
        Me.txtBoxCData2.Name = "txtBoxCData2"
        Me.txtBoxCData2.Size = New System.Drawing.Size(950, 23)
        Me.txtBoxCData2.TabIndex = 18
        '
        'txtBoxCData
        '
        Me.txtBoxCData.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBoxCData.Location = New System.Drawing.Point(16, 79)
        Me.txtBoxCData.Name = "txtBoxCData"
        Me.txtBoxCData.Size = New System.Drawing.Size(950, 23)
        Me.txtBoxCData.TabIndex = 17
        '
        'lblCData
        '
        Me.lblCData.AutoSize = True
        Me.lblCData.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCData.Location = New System.Drawing.Point(12, 58)
        Me.lblCData.Name = "lblCData"
        Me.lblCData.Size = New System.Drawing.Size(153, 20)
        Me.lblCData.TabIndex = 18
        Me.lblCData.Text = "Condition Type Data"
        '
        'ListBoxCTDataAnyAll
        '
        Me.ListBoxCTDataAnyAll.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListBoxCTDataAnyAll.FormattingEnabled = True
        Me.ListBoxCTDataAnyAll.ItemHeight = 16
        Me.ListBoxCTDataAnyAll.Location = New System.Drawing.Point(16, 84)
        Me.ListBoxCTDataAnyAll.Name = "ListBoxCTDataAnyAll"
        Me.ListBoxCTDataAnyAll.Size = New System.Drawing.Size(278, 132)
        Me.ListBoxCTDataAnyAll.TabIndex = 22
        Me.ListBoxCTDataAnyAll.Visible = False
        '
        'cBoxCType
        '
        Me.cBoxCType.DropDownHeight = 150
        Me.cBoxCType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cBoxCType.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cBoxCType.FormattingEnabled = True
        Me.cBoxCType.IntegralHeight = False
        Me.cBoxCType.Location = New System.Drawing.Point(15, 25)
        Me.cBoxCType.MaxDropDownItems = 30
        Me.cBoxCType.Name = "cBoxCType"
        Me.cBoxCType.Size = New System.Drawing.Size(301, 28)
        Me.cBoxCType.TabIndex = 20
        '
        'cBoxCTMetaState
        '
        Me.cBoxCTMetaState.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.FileSystem
        Me.cBoxCTMetaState.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cBoxCTMetaState.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cBoxCTMetaState.FormattingEnabled = True
        Me.cBoxCTMetaState.Items.AddRange(New Object() {"Default"})
        Me.cBoxCTMetaState.Location = New System.Drawing.Point(341, 25)
        Me.cBoxCTMetaState.MaxDropDownItems = 100
        Me.cBoxCTMetaState.Name = "cBoxCTMetaState"
        Me.cBoxCTMetaState.Size = New System.Drawing.Size(175, 28)
        Me.cBoxCTMetaState.Sorted = True
        Me.cBoxCTMetaState.TabIndex = 19
        '
        'btnCreateState
        '
        Me.btnCreateState.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCreateState.Location = New System.Drawing.Point(535, 23)
        Me.btnCreateState.Name = "btnCreateState"
        Me.btnCreateState.Size = New System.Drawing.Size(92, 32)
        Me.btnCreateState.TabIndex = 16
        Me.btnCreateState.Text = "CreateState"
        Me.btnCreateState.UseVisualStyleBackColor = True
        '
        'lblCTMetaState
        '
        Me.lblCTMetaState.AutoSize = True
        Me.lblCTMetaState.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCTMetaState.Location = New System.Drawing.Point(338, 3)
        Me.lblCTMetaState.Name = "lblCTMetaState"
        Me.lblCTMetaState.Size = New System.Drawing.Size(88, 20)
        Me.lblCTMetaState.TabIndex = 14
        Me.lblCTMetaState.Text = "Meta State"
        '
        'lblCType
        '
        Me.lblCType.AutoSize = True
        Me.lblCType.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCType.Location = New System.Drawing.Point(12, 3)
        Me.lblCType.Name = "lblCType"
        Me.lblCType.Size = New System.Drawing.Size(114, 20)
        Me.lblCType.TabIndex = 12
        Me.lblCType.Text = "Condition Type"
        '
        'btnDeleteATAnyAll
        '
        Me.btnDeleteATAnyAll.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDeleteATAnyAll.Location = New System.Drawing.Point(341, 149)
        Me.btnDeleteATAnyAll.Name = "btnDeleteATAnyAll"
        Me.btnDeleteATAnyAll.Size = New System.Drawing.Size(92, 32)
        Me.btnDeleteATAnyAll.TabIndex = 32
        Me.btnDeleteATAnyAll.Text = "De&lete"
        Me.btnDeleteATAnyAll.UseVisualStyleBackColor = True
        Me.btnDeleteATAnyAll.Visible = False
        '
        'dgvATMultiple
        '
        Me.dgvATMultiple.AllowUserToResizeRows = False
        Me.dgvATMultiple.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvATMultiple.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgvATMultiple.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvATMultiple.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.dgvATMultiple.Location = New System.Drawing.Point(13, 75)
        Me.dgvATMultiple.MultiSelect = False
        Me.dgvATMultiple.Name = "dgvATMultiple"
        Me.dgvATMultiple.RowHeadersVisible = False
        Me.dgvATMultiple.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.dgvATMultiple.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvATMultiple.ShowCellErrors = False
        Me.dgvATMultiple.ShowCellToolTips = False
        Me.dgvATMultiple.ShowEditingIcon = False
        Me.dgvATMultiple.Size = New System.Drawing.Size(302, 168)
        Me.dgvATMultiple.TabIndex = 29
        '
        'btnEditATAnyAll
        '
        Me.btnEditATAnyAll.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEditATAnyAll.Location = New System.Drawing.Point(342, 111)
        Me.btnEditATAnyAll.Name = "btnEditATAnyAll"
        Me.btnEditATAnyAll.Size = New System.Drawing.Size(92, 32)
        Me.btnEditATAnyAll.TabIndex = 31
        Me.btnEditATAnyAll.Text = "&Edit"
        Me.btnEditATAnyAll.UseVisualStyleBackColor = True
        Me.btnEditATAnyAll.Visible = False
        '
        'btnDown
        '
        Me.btnDown.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnDown.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDown.Location = New System.Drawing.Point(1102, 4)
        Me.btnDown.Name = "btnDown"
        Me.btnDown.Size = New System.Drawing.Size(129, 30)
        Me.btnDown.TabIndex = 27
        Me.btnDown.Text = "Row Down"
        Me.btnDown.UseVisualStyleBackColor = True
        '
        'btnAddATAnyAll
        '
        Me.btnAddATAnyAll.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddATAnyAll.Location = New System.Drawing.Point(342, 75)
        Me.btnAddATAnyAll.Name = "btnAddATAnyAll"
        Me.btnAddATAnyAll.Size = New System.Drawing.Size(92, 32)
        Me.btnAddATAnyAll.TabIndex = 30
        Me.btnAddATAnyAll.Text = "&Add"
        Me.btnAddATAnyAll.UseVisualStyleBackColor = True
        Me.btnAddATAnyAll.Visible = False
        '
        'btnTest
        '
        Me.btnTest.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTest.Location = New System.Drawing.Point(929, 18)
        Me.btnTest.Name = "btnTest"
        Me.btnTest.Size = New System.Drawing.Size(92, 32)
        Me.btnTest.TabIndex = 29
        Me.btnTest.Text = "Test"
        Me.btnTest.UseVisualStyleBackColor = True
        Me.btnTest.Visible = False
        '
        'btnChooseNav
        '
        Me.btnChooseNav.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnChooseNav.Location = New System.Drawing.Point(341, 22)
        Me.btnChooseNav.Name = "btnChooseNav"
        Me.btnChooseNav.Size = New System.Drawing.Size(92, 32)
        Me.btnChooseNav.TabIndex = 28
        Me.btnChooseNav.Text = "&Embed Nav"
        Me.btnChooseNav.UseVisualStyleBackColor = True
        '
        'btnLoadXML
        '
        Me.btnLoadXML.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnLoadXML.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLoadXML.Location = New System.Drawing.Point(1101, 63)
        Me.btnLoadXML.Name = "btnLoadXML"
        Me.btnLoadXML.Size = New System.Drawing.Size(129, 30)
        Me.btnLoadXML.TabIndex = 25
        Me.btnLoadXML.Text = "LoadXML"
        Me.btnLoadXML.UseVisualStyleBackColor = True
        '
        'btnSaveXML
        '
        Me.btnSaveXML.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSaveXML.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSaveXML.Location = New System.Drawing.Point(1101, 99)
        Me.btnSaveXML.Name = "btnSaveXML"
        Me.btnSaveXML.Size = New System.Drawing.Size(129, 30)
        Me.btnSaveXML.TabIndex = 24
        Me.btnSaveXML.Text = "SaveXML"
        Me.btnSaveXML.UseVisualStyleBackColor = True
        '
        'btnExportMeta
        '
        Me.btnExportMeta.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnExportMeta.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExportMeta.Location = New System.Drawing.Point(1101, 160)
        Me.btnExportMeta.Name = "btnExportMeta"
        Me.btnExportMeta.Size = New System.Drawing.Size(129, 30)
        Me.btnExportMeta.TabIndex = 26
        Me.btnExportMeta.Text = "Export To Meta"
        Me.btnExportMeta.UseVisualStyleBackColor = True
        '
        'buttonTest
        '
        Me.buttonTest.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.buttonTest.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.buttonTest.Location = New System.Drawing.Point(1101, 201)
        Me.buttonTest.Name = "buttonTest"
        Me.buttonTest.Size = New System.Drawing.Size(129, 30)
        Me.buttonTest.TabIndex = 20
        Me.buttonTest.Text = "Quit"
        Me.buttonTest.UseVisualStyleBackColor = True
        '
        'lblAData3
        '
        Me.lblAData3.AutoSize = True
        Me.lblAData3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAData3.Location = New System.Drawing.Point(11, 142)
        Me.lblAData3.Name = "lblAData3"
        Me.lblAData3.Size = New System.Drawing.Size(93, 20)
        Me.lblAData3.TabIndex = 11
        Me.lblAData3.Text = "Action Data"
        '
        'txtBoxAData3
        '
        Me.txtBoxAData3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBoxAData3.Location = New System.Drawing.Point(15, 162)
        Me.txtBoxAData3.Name = "txtBoxAData3"
        Me.txtBoxAData3.Size = New System.Drawing.Size(950, 22)
        Me.txtBoxAData3.TabIndex = 10
        '
        'lblAdata2
        '
        Me.lblAdata2.AutoSize = True
        Me.lblAdata2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAdata2.Location = New System.Drawing.Point(10, 100)
        Me.lblAdata2.Name = "lblAdata2"
        Me.lblAdata2.Size = New System.Drawing.Size(93, 20)
        Me.lblAdata2.TabIndex = 9
        Me.lblAdata2.Text = "Action Data"
        '
        'txtBoxAData2
        '
        Me.txtBoxAData2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBoxAData2.Location = New System.Drawing.Point(14, 120)
        Me.txtBoxAData2.Name = "txtBoxAData2"
        Me.txtBoxAData2.Size = New System.Drawing.Size(950, 22)
        Me.txtBoxAData2.TabIndex = 8
        '
        'cBoxAType
        '
        Me.cBoxAType.DropDownHeight = 150
        Me.cBoxAType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cBoxAType.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cBoxAType.FormattingEnabled = True
        Me.cBoxAType.IntegralHeight = False
        Me.cBoxAType.Location = New System.Drawing.Point(15, 22)
        Me.cBoxAType.Name = "cBoxAType"
        Me.cBoxAType.Size = New System.Drawing.Size(301, 28)
        Me.cBoxAType.TabIndex = 7
        '
        'cBoxATMetaState
        '
        Me.cBoxATMetaState.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cBoxATMetaState.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cBoxATMetaState.FormattingEnabled = True
        Me.cBoxATMetaState.Items.AddRange(New Object() {"Default"})
        Me.cBoxATMetaState.Location = New System.Drawing.Point(341, 22)
        Me.cBoxATMetaState.MaxDropDownItems = 100
        Me.cBoxATMetaState.Name = "cBoxATMetaState"
        Me.cBoxATMetaState.Size = New System.Drawing.Size(175, 28)
        Me.cBoxATMetaState.Sorted = True
        Me.cBoxATMetaState.TabIndex = 6
        Me.cBoxATMetaState.Visible = False
        '
        'lblATMetaState
        '
        Me.lblATMetaState.AutoSize = True
        Me.lblATMetaState.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblATMetaState.Location = New System.Drawing.Point(337, 3)
        Me.lblATMetaState.Name = "lblATMetaState"
        Me.lblATMetaState.Size = New System.Drawing.Size(84, 20)
        Me.lblATMetaState.TabIndex = 5
        Me.lblATMetaState.Text = "MetaState"
        Me.lblATMetaState.Visible = False
        '
        'txtBoxAData
        '
        Me.txtBoxAData.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBoxAData.Location = New System.Drawing.Point(14, 75)
        Me.txtBoxAData.Name = "txtBoxAData"
        Me.txtBoxAData.Size = New System.Drawing.Size(950, 22)
        Me.txtBoxAData.TabIndex = 3
        '
        'lblAData
        '
        Me.lblAData.AutoSize = True
        Me.lblAData.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAData.Location = New System.Drawing.Point(10, 54)
        Me.lblAData.Name = "lblAData"
        Me.lblAData.Size = New System.Drawing.Size(93, 20)
        Me.lblAData.TabIndex = 2
        Me.lblAData.Text = "Action Data"
        '
        'lblAType
        '
        Me.lblAType.AutoSize = True
        Me.lblAType.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAType.Location = New System.Drawing.Point(10, 3)
        Me.lblAType.Name = "lblAType"
        Me.lblAType.Size = New System.Drawing.Size(92, 20)
        Me.lblAType.TabIndex = 1
        Me.lblAType.Text = "Action Type"
        '
        'btnCreateRule
        '
        Me.btnCreateRule.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnCreateRule.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCreateRule.Location = New System.Drawing.Point(1101, 393)
        Me.btnCreateRule.Name = "btnCreateRule"
        Me.btnCreateRule.Size = New System.Drawing.Size(129, 32)
        Me.btnCreateRule.TabIndex = 15
        Me.btnCreateRule.Text = "&Create Rule"
        Me.btnCreateRule.UseVisualStyleBackColor = True
        '
        'dgvMetaRules
        '
        Me.dgvMetaRules.AllowUserToResizeRows = False
        Me.dgvMetaRules.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvMetaRules.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgvMetaRules.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvMetaRules.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.dgvMetaRules.Location = New System.Drawing.Point(10, 49)
        Me.dgvMetaRules.MultiSelect = False
        Me.dgvMetaRules.Name = "dgvMetaRules"
        Me.dgvMetaRules.RowHeadersVisible = False
        Me.dgvMetaRules.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvMetaRules.ShowCellErrors = False
        Me.dgvMetaRules.ShowCellToolTips = False
        Me.dgvMetaRules.ShowEditingIcon = False
        Me.dgvMetaRules.Size = New System.Drawing.Size(1234, 312)
        Me.dgvMetaRules.TabIndex = 21
        '
        'btnUpdateRule
        '
        Me.btnUpdateRule.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnUpdateRule.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUpdateRule.Location = New System.Drawing.Point(1101, 431)
        Me.btnUpdateRule.Name = "btnUpdateRule"
        Me.btnUpdateRule.Size = New System.Drawing.Size(129, 32)
        Me.btnUpdateRule.TabIndex = 22
        Me.btnUpdateRule.Text = "&Update Rule"
        Me.btnUpdateRule.UseVisualStyleBackColor = True
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.Filter = "XML files (*.xml)|*.xml"
        Me.OpenFileDialog1.InitialDirectory = "C:\"
        '
        'SaveFileDialog1
        '
        Me.SaveFileDialog1.Filter = "XML files (*.xml)|*.xml"
        Me.SaveFileDialog1.InitialDirectory = "C:\"
        '
        'SaveFileDialogMeta
        '
        Me.SaveFileDialogMeta.Filter = "Meta files (*.met)|*.met"
        Me.SaveFileDialogMeta.InitialDirectory = "C:\"
        Me.SaveFileDialogMeta.Title = "Export Meta"
        '
        'btnATCreateState
        '
        Me.btnATCreateState.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnATCreateState.Location = New System.Drawing.Point(535, 18)
        Me.btnATCreateState.Name = "btnATCreateState"
        Me.btnATCreateState.Size = New System.Drawing.Size(92, 32)
        Me.btnATCreateState.TabIndex = 30
        Me.btnATCreateState.Text = "CreateState"
        Me.btnATCreateState.UseVisualStyleBackColor = True
        '
        'frmMain
        '
        Me.AcceptButton = Me.btnCreateRule
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1234, 861)
        Me.Controls.Add(Me.btnCreateRule)
        Me.Controls.Add(Me.btnUpdateRule)
        Me.Controls.Add(Me.dgvMetaRules)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Mission:Impossible - Meta Builder"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel1.PerformLayout()
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.Panel2.PerformLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        CType(Me.dgvAnyAll, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvATMultiple, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvMetaRules, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles Me.Load




    End Sub

    'Friend WithEvents MiMbTest As MiMbTest
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents NewToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OpenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SaveToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EditToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CopyToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PasteToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents NavRoutesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpFileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents tsbNew As ToolStripButton
    Friend WithEvents tsbOpen As ToolStripButton
    Friend WithEvents tsbSave As ToolStripButton
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SplitContainer1 As SplitContainer
    Friend WithEvents lblCData As Label
    Friend WithEvents txtBoxCData As TextBox
    Friend WithEvents btnCreateRule As Button
    Friend WithEvents btnCreateState As Button
    Friend WithEvents lblCTMetaState As Label
    Friend WithEvents lstBoxCTMetaState As ListBox
    Friend WithEvents lblCType As Label
    Friend WithEvents lstBoxCType As ListBox
    Friend WithEvents lblATMetaState As Label
    Friend WithEvents lstBoxATMetaState As ListBox
    Friend WithEvents txtBoxAData As TextBox
    Friend WithEvents lblAData As Label
    Friend WithEvents lblAType As Label
    Friend WithEvents lstBoxAData As ListBox
    Friend WithEvents cBoxCTMetaState As ComboBox
    Friend WithEvents cBoxATMetaState As ComboBox
    Friend WithEvents cBoxCType As ComboBox
    Friend WithEvents cBoxAType As ComboBox
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents tsbExportMeta As ToolStripButton
    Friend WithEvents MetaDataDataGridView As DataGridView
    Friend WithEvents SaveAsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OptionsToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents buttonTest As Button
    Friend WithEvents StateValueDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents StateVarDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents CTypeValueDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents CTypeVarDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents CDataValueDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents CDataVarDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ATypeValueDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ATypeVarDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ADataValueDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ADataVarDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents dgvMetaRules As DataGridView
    Friend WithEvents btnUpdateRule As Button
    Friend WithEvents btnDeleteRule As Button
    Friend WithEvents btnSaveXML As Button
    Friend WithEvents btnLoadXML As Button
    Friend WithEvents btnExportMeta As Button
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents SaveFileDialog1 As SaveFileDialog
    Friend WithEvents btnDown As Button
    Friend WithEvents SaveFileDialogMeta As SaveFileDialog
    Friend WithEvents btnUp As Button
    Friend WithEvents btnInsertRule As Button
    Friend WithEvents btnAddAnyAll As Button
    Friend WithEvents ListBoxCTDataAnyAll As ListBox
    Friend WithEvents lblCData2 As Label
    Friend WithEvents txtBoxCData2 As TextBox
    Friend WithEvents lblAdata2 As Label
    Friend WithEvents txtBoxAData2 As TextBox
    Friend WithEvents lblAData3 As Label
    Friend WithEvents txtBoxAData3 As TextBox
    Friend WithEvents cBoxCTAnyAll As ComboBox
    Friend WithEvents btnDeleteAnyAll As Button
    Friend WithEvents btnEditAnyAll As Button
    Friend WithEvents btnChooseNav As Button
    Friend WithEvents btnTest As Button
    Friend WithEvents dgvAnyAll As DataGridView
    Friend WithEvents FileToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents NewToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents OpenToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents SaveToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents ToolsToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents OptionsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents ToolStripButtonNew As ToolStripButton
    Friend WithEvents ToolStripButtonOpen As ToolStripButton
    Friend WithEvents ToolStripButtonSave As ToolStripButton
    Friend WithEvents ToolStripSeparator2 As ToolStripSeparator
    Friend WithEvents ToolStripButtonExport As ToolStripButton
    Friend WithEvents dgvATMultiple As DataGridView
    Friend WithEvents btnDeleteATAnyAll As Button
    Friend WithEvents btnEditATAnyAll As Button
    Friend WithEvents btnAddATAnyAll As Button
    Friend WithEvents btnATCreateState As Button
End Class
