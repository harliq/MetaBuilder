﻿Module SetForm
    ' This module is to set form design depending on the selected Conditon or Action Type
    'Called from Click/change events to DGV or rule selection, Conditiong or Action ComboBox Changes/Selected Indexes
    Public SaveWork As Boolean = False

    Sub ResetAll()
        ResetAction()
        ResetCondition()
    End Sub

    'Condition Types
    Sub ResetCondition()
        frmMain.lblCData.Visible = True
        frmMain.txtBoxCData.Enabled = True
        frmMain.txtBoxCData2.Enabled = True
        frmMain.txtBoxCData.Visible = False
        frmMain.txtBoxCData2.Visible = False
        frmMain.lblCData2.Visible = False
        frmMain.ListBoxCTDataAnyAll.Visible = False
        frmMain.btnAddAnyAll.Visible = False
        frmMain.cBoxCTAnyAll.Visible = False
        frmMain.btnDeleteAnyAll.Visible = False
        frmMain.btnEditAnyAll.Visible = False
        frmMain.dgvAnyAll.Visible = False
        'Making everyting blank
        frmMain.txtBoxCData.Text = ""
        frmMain.txtBoxCData2.Text = ""
        frmMain.lblCData.Text = ""
        frmMain.lblCData2.Text = ""
        frmMain.cBoxCTMetaState.Text = "Default"


    End Sub
    Sub CTSingle()
        frmMain.txtBoxCData.Visible = True
    End Sub
    Sub CTDouble()
        frmMain.txtBoxCData.Visible = True
        frmMain.txtBoxCData2.Visible = True
        frmMain.lblCData2.Visible = True
    End Sub
    Sub CTAnyAll()
        frmMain.dgvAnyAll.Visible = True
        frmMain.btnAddAnyAll.Visible = True
        frmMain.btnDeleteAnyAll.Visible = True
        frmMain.btnEditAnyAll.Visible = True

    End Sub
    Sub BlankRow()
        frmMain.txtBoxCData.Enabled = True
        frmMain.txtBoxCData.Visible = False
        frmMain.txtBoxCData2.Visible = False
        frmMain.txtBoxAData.Visible = False

    End Sub
    Sub CTNever()
        frmMain.lblCData.Text = "Never"
        'frmMain.txtBoxCData.Enabled = False
        'frmMain.txtBoxCData.Visible = False

    End Sub
    Sub CTAlways()
        frmMain.lblCData.Text = "Always"
        ' frmMain.txtBoxCData.Enabled = False
        'frmMain.txtBoxCData.Visible = False

    End Sub
    Sub CTAll()
        frmMain.lblCData.Text = "All"
        'frmMain.txtBoxCData.Enabled = True
        'frmMain.txtBoxCData.Visible = False
        frmMain.ListBoxCTDataAnyAll.Visible = True
        frmMain.btnAddAnyAll.Visible = True
        'frmMain.cBoxCTAnyAll.Visible = True
        frmMain.btnEditAnyAll.Visible = True
        frmMain.btnDeleteAnyAll.Visible = True


        'add Listbox for All Conditons
    End Sub
    Sub CTAny()
        frmMain.lblCData.Text = "Any"
        'frmMain.txtBoxCData.Enabled = False
        'frmMain.txtBoxCData.Visible = False
        frmMain.ListBoxCTDataAnyAll.Visible = True
        frmMain.btnAddAnyAll.Visible = True

        'add Listbox for Any Conditons

    End Sub
    Sub CTChatMessage()
        frmMain.lblCData.Text = "Chat Message"
        'frmMain.txtBoxCData.Enabled = True
        frmMain.txtBoxCData.Visible = True

    End Sub
    Sub CTMainPackSlotsLE()
        frmMain.lblCData.Text = "Pack Slots <="
        'frmMain.txtBoxCData.Enabled = True
        frmMain.txtBoxCData.Visible = True

    End Sub
    Sub CTSecondsinStateGE()
        frmMain.lblCData.Text = "Seconds in State >="
        'frmMain.txtBoxCData.Enabled = True
        frmMain.txtBoxCData.Visible = True

    End Sub
    Sub CTNavRouteEmpty()
        frmMain.lblCData.Text = "Nav Route Empty"
        'frmMain.txtBoxCData.Enabled = False
        'frmMain.txtBoxCData.Visible = False
    End Sub
    Sub CTDied()
        frmMain.lblCData.Text = "On Death"
        'frmMain.txtBoxCData.Enabled = False
        'frmMain.txtBoxCData.Visible = False
    End Sub
    Sub CTVendorOpen()
        frmMain.lblCData.Text = "Vendor Open"
        'frmMain.txtBoxCData.Enabled = True
        'frmMain.txtBoxCData.Visible = True
    End Sub
    Sub CTVendorClosed()
        frmMain.lblCData.Text = "Vendor Closed"
        'frmMain.txtBoxCData.Enabled = True
        'frmMain.txtBoxCData.Visible = True

    End Sub
    Sub CTItemCountLE()
        frmMain.lblCData.Text = "Item Name"
        frmMain.lblCData2.Text = "Item Count"
        frmMain.lblCData2.Visible = True
        'frmMain.txtBoxCData.Enabled = True
        frmMain.txtBoxCData.Visible = True
        frmMain.txtBoxCData2.Visible = True
        '**DONE**Add More labels, and Another Text Entry Box (2 Values)
    End Sub
    Sub CTItemCountGE()
        frmMain.lblCData.Text = "Item Name"
        frmMain.lblCData2.Text = "Item Count"
        frmMain.lblCData2.Visible = True
        ' frmMain.txtBoxCData.Enabled = True
        frmMain.txtBoxCData.Visible = True
        frmMain.txtBoxCData2.Visible = True
        '**DONE** Add More labels, and Another Text Entry Box (2 Values)
    End Sub
    Sub CTMonsterCountWithinDistance()
        frmMain.lblCData.Text = "Monster Count Within Distance"
        frmMain.txtBoxCData.Enabled = True
        frmMain.txtBoxCData.Visible = True
    End Sub
    Sub CTMonsterWithPriorityWithinDistance()
        frmMain.lblCData.Text = "Monster Priority Within Distance"
        frmMain.txtBoxCData.Enabled = True
        frmMain.txtBoxCData.Visible = True
    End Sub
    Sub CTNeedToBuff()
        frmMain.lblCData.Text = "Need to Buff"
        'frmMain.txtBoxCData.Enabled = False
        'frmMain.txtBoxCData.Visible = False

    End Sub
    Sub CTNoMonsterWithinDistance()
        frmMain.lblCData.Text = "No Monster Within Distance"
        'frmMain.txtBoxCData.Enabled = True
        frmMain.txtBoxCData.Visible = True
    End Sub
    Sub CTLandBlockE()
        frmMain.lblCData.Text = "Landblock ="
        'frmMain.txtBoxCData.Enabled = True
        frmMain.txtBoxCData.Visible = True

    End Sub
    Sub CTLandColumnE()
        frmMain.lblCData.Text = "Landcell ="
        'frmMain.txtBoxCData.Enabled = True
        frmMain.txtBoxCData.Visible = True
    End Sub
    Sub CTPortalSpaceEnter()
        frmMain.lblCData.Text = "Enter Portal Space"
        'frmMain.txtBoxCData.Enabled = False
        'frmMain.txtBoxCData.Visible = False

    End Sub
    Sub CTPortalSpaceExit()
        frmMain.lblCData.Text = "Exit Portal Space"
        'frmMain.txtBoxCData.Enabled = False
        'frmMain.txtBoxCData.Visible = False

    End Sub
    Sub CTNot()
        frmMain.lblCData.Text = "Not"
        'frmMain.txtBoxCData.Enabled = True
        'frmMain.txtBoxCData.Visible = True

    End Sub
    Sub CTSecondsInStatePersistGE()
        frmMain.lblCData.Text = "Seconds in State Persist >="
        'frmMain.txtBoxCData.Enabled = True
        frmMain.txtBoxCData.Visible = True

    End Sub
    Sub CTTimeLeftOnSpellGE()
        frmMain.lblCData.Text = "Time left on spell >= (Seconds)"
        'frmMain.txtBoxCData.Enabled = True
        frmMain.txtBoxCData.Visible = True

    End Sub
    Sub CTBurdenPercentGE()
        frmMain.lblCData.Text = "Burden Percentage >="
        'frmMain.txtBoxCData.Enabled = True
        frmMain.txtBoxCData.Visible = True

    End Sub
    Sub CTDistanceToAnyRoutePointGE()
        frmMain.lblCData.Text = "Distance to Route Point >="
        'frmMain.txtBoxCData.Enabled = True
        frmMain.txtBoxCData.Visible = True

    End Sub
    Sub CTExpression()
        frmMain.lblCData.Text = "Chat Expression"
        'frmMain.txtBoxCData.Enabled = True
        frmMain.txtBoxCData.Visible = True

    End Sub
    Sub CTClientDialogPopup()
        frmMain.lblCData.Text = "Client Dialog PopUp - DISABLED, NOT IN GAME"
        'frmMain.txtBoxCData.Enabled = False
        'frmMain.txtBoxCData.Visible = False

    End Sub
    Sub CTChatMessageCapture()
        frmMain.lblCData.Text = "Chat Message Pattern"
        frmMain.lblCData2.Text = "Chat ColorID List"
        frmMain.lblCData2.Visible = True
        'frmMain.txtBoxCData.Enabled = True
        frmMain.txtBoxCData.Visible = True
        frmMain.txtBoxCData2.Visible = True

    End Sub

    'Action Types
    Sub ResetAction()
        'Label A Data is always visible
        frmMain.lblAData.Visible = True
        'Making sure Text boxes enabled
        frmMain.txtBoxAData.Enabled = True
        frmMain.txtBoxAData2.Enabled = True
        frmMain.txtBoxAData3.Enabled = True
        'Hiding everything Except Label A Data
        frmMain.txtBoxAData.Visible = False
        frmMain.txtBoxAData2.Visible = False
        frmMain.txtBoxAData3.Visible = False
        frmMain.cBoxATMetaState.Visible = False
        frmMain.lblAdata2.Visible = False
        frmMain.lblAData3.Visible = False
        frmMain.lblATMetaState.Visible = False
        frmMain.btnChooseNav.Visible = False
        'Clearing the fields.
        frmMain.lblAData.Text = ""
        frmMain.lblAdata2.Text = ""
        frmMain.lblAData3.Text = ""
        frmMain.txtBoxAData.Text = ""
        frmMain.txtBoxAData2.Text = ""
        frmMain.txtBoxAData3.Text = ""
        frmMain.cBoxATMetaState.Text = "Default"
    End Sub

    Sub ATSingleRule()
        frmMain.txtBoxAData.Visible = True
    End Sub
    Sub ATDoubleRule()
        frmMain.txtBoxAData.Visible = True
        frmMain.txtBoxAData2.Visible = True
        frmMain.lblAdata2.Visible = True
    End Sub
    Sub ATTripleRule()
        frmMain.txtBoxAData.Visible = True
        frmMain.txtBoxAData2.Visible = True
        frmMain.txtBoxAData3.Visible = True

        frmMain.lblAData.Visible = True
        frmMain.lblAdata2.Visible = True
        frmMain.lblAData3.Visible = True
    End Sub
    Sub ATSetStateRule()
        frmMain.cBoxATMetaState.Visible = True
        frmMain.lblATMetaState.Visible = True
    End Sub
    Sub ATMultiple()
        'frmMain.txtBoxAData.Enabled = True
        frmMain.txtBoxAData.Visible = True
        frmMain.cBoxATMetaState.Visible = False
        frmMain.lblATMetaState.Visible = False
        frmMain.lblAData.Visible = True
        frmMain.lblAData.Text = "Multiple"
    End Sub
    Sub ATSet(ATString As String)
        Select Case ATString 'This now replaces all the crap code I had for reseting the form for ActionTypes.  Should fix issues.
            Case "0", "None"
            Case "1", "SetState"
                SetForm.ATSetStateRule()
            Case "2", "ChatCommand"
                SetForm.ATSingleRule()
                frmMain.lblAData.Text = "Chat Command"
            Case "3", "Multiple"
                SetForm.ATMultiple()
                MsgBox("Not yet Implemented")
            Case "4", "EmbeddedNavRoute"
                SetForm.ATSingleRule()
                frmMain.btnChooseNav.Visible = True
                frmMain.lblAData.Text = "Embedded Nav - Choose File"
            Case "5", "CallState"
                SetForm.ATSetStateRule()
                frmMain.lblAData.Text = "Call State"
            Case "6", "ReturnFromCall"
                frmMain.lblAData.Text = "Return From Call"
                frmMain.txtBoxAData.Text = "0"
            Case "7", "ExpressionAct"
                SetForm.ATSingleRule()
                frmMain.lblAData.Text = "Expression Action"
            Case "8", "ChatWithExpression"
                SetForm.ATSingleRule()
                frmMain.lblAData.Text = "Chat with Expression"
            Case "9", "WatchdogSet"
                SetForm.ATTripleRule()
                frmMain.lblAData.Text = "State to Call:"
                frmMain.lblAdata2.Text = "Movement Range (Meters):"
                frmMain.lblAData3.Text = "Time Span (Seconds):"
            Case "10", "WatchdogClear"
                frmMain.lblAData.Text = "WatchDog Clear"
            Case "11", "GetVTOption"
                SetForm.ATDoubleRule()
                frmMain.lblAData.Text = "Option to Get"
                frmMain.lblAdata2.Text = "Expression Variable Target"
            Case "12", "SetVTOption"
                SetForm.ATDoubleRule()
                frmMain.lblAData.Text = "Option to Set"
                frmMain.lblAdata2.Text = "Expresssion (True/False, Value)"
        End Select
    End Sub
    Sub CTSet(CTString As String)

        Select Case CTString
            Case "0", "Never"
                frmMain.lblCData.Text = "Never"

            Case "1", "Always"
                frmMain.lblCData.Text = "Always"

            Case "2", "All"

                SetForm.CTAnyAll()
                frmMain.lblCData.Text = "All"

                'cBoxCTAnyAll.Items.AddRange([Enum].GetNames(GetType(MetaConditionTypeID)))
                'cBoxCTAnyAll.SelectedIndex = 0
                'SetForm.CTAll()
                'SetAnyAllTable()

            Case "3", "Any"
                SetForm.CTAnyAll()
                frmMain.lblCData.Text = "Any"

            Case "4", "ChatMessage"
                SetForm.CTSingle()
                frmMain.lblCData.Text = "Chat Message"

            Case "5", "MainPackSlotsLE"
                SetForm.CTSingle()
                frmMain.lblCData.Text = "Main Pack Slots Less than or Equal To:"

            Case "6", "SecondsInStateGE"
                SetForm.CTSingle()
                frmMain.lblCData.Text = "Seconds in State Greater than or Equal To:"

            Case "7", "NavrouteEmpty"
                frmMain.lblCData.Text = "Nav Route Empty"

            Case "8", "Died"
            Case "9", "VendorOpen"
            Case "10", "VendorClosed"
            Case "11", "ItemCountLE"
                SetForm.CTDouble()
                frmMain.lblCData.Text = "Item:"
                frmMain.lblCData2.Text = "Number Less than or Equal To:"
            Case "12", "ItemCountGE"
                SetForm.CTDouble()
                frmMain.lblCData.Text = "Item:"
                frmMain.lblCData2.Text = "Number Greater than or Equal To:"
            Case "13", "MonsterCountWithinDistance"
                SetForm.CTSingle()
                frmMain.lblCData.Text = "Number of Monsters within Distance:"
            Case "14", "MonstersWithPriorityWithinDistance"
                frmMain.lblCData.Text = "Monsters with priority within Distance:"
                SetForm.CTSingle()
            Case "15", "NeedToBuff"
            Case "16", "NoMonstersWithinDistance"
                SetForm.CTSingle()
                frmMain.lblCData.Text = "No Monsters within Distance:"
            Case "17", "LandBlockE"
                SetForm.CTSingle()
                frmMain.lblCData.Text = "Land Block Equals:"
            Case "18", "LandCellE"
                SetForm.CTSingle()
                frmMain.lblCData.Text = "Land Cell Equals:"

            Case "19", "PortalspaceEnter"
            Case "20", "PortalspaceExit"
            Case "21", "Not"
                MsgBox("Not yet Implemented")
            Case "22", "SecondsInStatePersietGE"
                SetForm.CTSingle()
                frmMain.lblCData.Text = "Seconds in State Persist:"
            Case "23", "TimeLeftOnSpellGE"
                SetForm.CTSingle()
                frmMain.lblCData.Text = "Time Left on Spell Greater than or Equal To:"
            Case "24", "BurdenPercentGE"
                SetForm.CTSingle()
                frmMain.lblCData.Text = "Burden Percentage Greater than or Equal To:"
            Case "25", "DistanceToAnyRoutePointGE"
                SetForm.CTSingle()
                frmMain.lblCData.Text = "Distance to Any Route Point Greater than or Equal To:"
            Case "26", "Expression"
                SetForm.CTSingle()
                frmMain.lblCData.Text = "Chat Expression:"

            Case "27", "ClientDialogPopup"
                frmMain.lblCData.Text = "Client Dialog PopUp - DISABLED, NOT IN GAME:"
                MsgBox("Not yet Implemented")
            Case "28", "ChatMessageCapture"
                SetForm.CTDouble()
                frmMain.lblCData.Text = "Chat Message Pattern:"
                frmMain.lblCData2.Text = "Chat ColorID List:"

        End Select
    End Sub
End Module
