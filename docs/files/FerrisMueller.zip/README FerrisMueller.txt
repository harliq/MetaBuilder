**For Beta Testing**
FilesIncluded:
FerrisMueller ChoasHelper Config and Layout
FerrisMueller.xml (for MiMB)
FerrisMueller.met
README FerrisMueller.txt


**FerrisMueller**
FerrisMueller is a meta you run on all your clients to offload Salvage, Items & Trophies to Mules.  It will give every item in characters inventory to the character or mule you specify.

To use, you will need to change 5 places in the Meta (or XML and Export Meta).  Need to change ControlCharacterOne to the character you want sending out the commands.  However you can just use it on one client to just off load that client without changing anything.

A ChoasHelper file is included for ease of use.

*Items/Trophies*
To use, select the character you want to give items to, then click the Select Mule/Character to Give Button.  Then click the item in your inventory and click the Select & Give Item.
There are also buttons that can be programmed for common items, such as peas, mfks, etc.  Having predefined buttons is useful, as you may not have the item on the Control Character, but maybe on another.

*Salvage*
Salvage has to use the WCID. So you just select the character to give the salvage to, then click a predefined button.  I do not have a lot of thing predefined, but the more common ones are there.  You can easily add more to the Chaos Menu.

*Commands*
#gacharselect - Selects Mule/Character to Give Items to [No Parameters]
#gaitemselect - Selects the item you clicked on in your inventory and gives to the character you selected [No Parameters] (Use after you use the #gacharselect command).
#gasalvage [WCID] - Gives salavage of ID to the character you selected. [WCID] example to give bag of steel: #gasalvage 20993
#giveallitem [Item Name] - Gives item with name you specify to the character you selected. [Item Name] #giveallitem Mana Forge Key
#halt - Stops giving all items.  This works pretty good, but it is influenced by lag, and there is a split second in meta it will not work, however clicking it again after it fails, tends to stop giving items.



